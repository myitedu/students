$(function () {

    generate_winning_numbers();

    function generate_winning_numbers() {

        let numbers = [
            Math.floor(Math.random() * 100),
            Math.floor(Math.random() * 100),
            Math.floor(Math.random() * 100),
            Math.floor(Math.random() * 100),
            Math.floor(Math.random() * 100),
            Math.floor(Math.random() * 100),
        ];
        let winning_numbers = ''
        let matching_numbers = [];
        for (let i = 0; i < 6; i++) {
            let n = numbers[i];
            let id = i;
            id++;
            let un = $("#number"+id).val();
            winning_numbers += "<div>" + n + "</div>"
            if (n==un){
                matching_numbers.push(i);
            }
        }

        //$(".matching_numbers").html(matching_numbers);
        $(".winning_numbers").html(winning_numbers);

        matching_numbers.forEach(function (n) {
            $("input").eq(n).css("background-color","red");
        })
    }

    $("#btn_roll").click(function () {
       generate_winning_numbers();
    });


});